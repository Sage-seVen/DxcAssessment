export interface doctor{
    id:number;
	name:string;
	degree:string;
	hospital:string;
}