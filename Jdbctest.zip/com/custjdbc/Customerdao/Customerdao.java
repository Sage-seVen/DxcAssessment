package com.custjdbc.Customerdao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.custjdbc.pojo.Customer;
import com.myjdbc.dbutil.DbConn;

public class Customerdao {
	
	public static String saveCustomer(Customer customer)
	{
		String id=customer.getCustName().substring(0,2)+customer.getCustLastName().substring(0,2);;
		
	try{
		Connection con=DbConn.getConnection();
	
		String sql="insert into customer values(?,?,?,?)";
		String sql1="select idsequence.nextval from dual";
		PreparedStatement stat=con.prepareStatement(sql);
		PreparedStatement stat1=con.prepareStatement(sql1);
		ResultSet rs= stat1.executeQuery();
		while(rs.next())
		{
			if(rs.getInt(1)<10)
				id=id+"00"+rs.getInt(1);
			
			else if(rs.getInt(1)>10) {
			id=id+"0"+rs.getInt(1);
				if(rs.getInt(1)>100)
					id=id+rs.getInt(1);
				
//System.out.println(rs.getInt(1));
			}
			
		}
		
		customer.setCustId(id);
		stat.setString(1, customer.getCustId());
		stat.setString(2, customer.getCustName());
		stat.setString(3, customer.getCustLastName());
		stat.setString(4, customer.getAddress());
		
		
	
		int res= stat.executeUpdate();
		if(res>0)
		return "Customer Data saved";
		}
	
	catch (Exception e){
	e.printStackTrace();
	}

	return "Cannot save Customer Data";

	}

}
