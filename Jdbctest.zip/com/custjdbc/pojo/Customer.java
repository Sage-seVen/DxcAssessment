package com.custjdbc.pojo;

public class Customer {

	String CustId;
	String CustName;
	String CustLastName;
	String Address;


	public String getCustId() {
		return CustId;
	}
	public void setCustId(String custId) {
		CustId = custId;
	}
	public String getCustName() {
		return CustName;
	}
	public void setCustName(String custName) {
		CustName = custName;
	}
	public String getCustLastName() {
		return CustLastName;
	}
	public void setCustLastName(String custLastName) {
		CustLastName = custLastName;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}


	@Override
	public String toString() {

	return getCustId()+" "+getCustName()+" "+getCustLastName()+" "+getAddress();

	}

}
