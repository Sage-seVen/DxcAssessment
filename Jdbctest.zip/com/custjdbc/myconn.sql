create table customer(custid varchar(20), custfname varchar(20), custlname varchar(20), custaddress varchar(20));

CREATE SEQUENCE idsequence
 START WITH     1
 INCREMENT BY   1
 MAXVALUE  100
 MINVALUE 0
 NOCYCLE;
 
 select idsequence.nextval from dual;
 
 
 drop sequence idsequence;