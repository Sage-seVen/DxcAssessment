package com.custjdbc.service;


import com.custjdbc.Customerdao.Customerdao;
import com.custjdbc.pojo.Customer;

public class CustomerService {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Customer customer = new Customer();
		customer.setCustName("Virat");
		customer.setCustLastName("Kohli");
		customer.setAddress("Delhi se hu");
		
		System.out.println(Customerdao.saveCustomer(customer));
	}

}
